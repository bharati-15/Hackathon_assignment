package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DbHandler2 extends SQLiteOpenHelper {
    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "usersdb";
    private static final String TABLE_NAME = "userdetails";
    private static final String KEY_ID = "id";
    private static final String KEY_editTextUsername = " username";
    private static final String KEY_editTextPassword = "password";


    public DbHandler2(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        try {
            String CREATE_TABLE = "create table " + TABLE_NAME + "("
                    + KEY_ID + " Integer PRIMARY KEY AUTOINCREMENT,"
                    + KEY_editTextUsername + " TEXT,"
                    + KEY_editTextPassword + " TEXT" +
                    ")";
            sqLiteDatabase.execSQL(CREATE_TABLE);
        } catch (Exception e) {
            Log.d("msg1", e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // Drop older table if exist
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // Create tables again
        onCreate(sqLiteDatabase);
    }

    void insertUserDetails(String username, String password) {
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        //Create a new map of values, where column names are the keys
        ContentValues cValues = new ContentValues();
        cValues.put(KEY_editTextUsername, username);
        cValues.put(KEY_editTextPassword, password);

        // Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(TABLE_NAME, null, cValues);
        db.close();
    }
}
